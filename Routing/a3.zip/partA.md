# add-flow entries

`in_port`: an input port specified by the last two digits of the MAC address of an incoming connection

`ip`: specifies ip addresses

`nw_src`: the source ip of the packet (specified by source host)

`nw_dst`: the destination ip of the packet (speciied by destination host)

`actions`: actions to take after matching

`mod_dl_src`: the MAC address source of the outgoing link of the current switch

`mod_dl_dst`: the MAC address destination of the incoming link of the next switch